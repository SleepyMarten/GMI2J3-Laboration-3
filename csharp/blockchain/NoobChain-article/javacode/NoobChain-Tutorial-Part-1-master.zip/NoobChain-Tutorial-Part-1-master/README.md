# NoobChain-Tutorial-Part-1
A Simple Java Blockchain for educational purposes. 

This is for https://medium.com/programmers-blockchain/create-simple-blockchain-java-tutorial-from-scratch-6eeed3cb03fa tutorial.
*If you have any other questions you can message me on the [Blockchain Developers Club](https://discord.gg/ZsyQqyk) discord server.*

# Dependencies: You will need to import GSON:
- gson [gson-2.8.2.jar](http://central.maven.org/maven2/com/google/code/gson/gson/2.8.2/gson-2.8.2.jar)

# Java Version:
- JDK1.8.0_77

contact: kassCrypto@gmail.com
