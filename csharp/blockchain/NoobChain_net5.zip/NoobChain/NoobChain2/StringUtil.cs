﻿using Newtonsoft.Json;
using Secp256k1Net;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace NoobChain
{
    public class StringUtil
    {
        private ref struct Signature
        {
            public Span<byte> signature;
        }


        /// <summary>
        /// Applies Sha256 to a string and returns the result
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string ApplySha256(string input)
        {
            StringBuilder hexString = new StringBuilder();

            using (var hash = SHA256.Create())
            {
                try
                {
                    byte[] hashBytes = hash.ComputeHash(Encoding.UTF8.GetBytes(input));
                    foreach (byte b in hashBytes)
                        hexString.Append(b.ToString("x2"));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(Environment.NewLine + "SHA exception: " + ex.ToString());
                }
            }
            return hexString.ToString();
        }


        /// <summary>
        /// Short hand helper to turn Object into a JSON string
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string GetJson(object obj)
        {
            return JsonConvert.SerializeObject(obj, Formatting.Indented);
        }


        /// <summary>
        /// Returns difficulty string target, to compare to hash. eg difficulty of 5 will return "00000" 
        /// </summary>
        /// <param name="difficulty"></param>
        /// <returns></returns>
        public static string GetDifficultyString(int difficulty)
        {
            return (new string(new char[difficulty])).Replace('\0', '0');
        }



        /// <summary>
        /// Applies ECDSA Signature and returns the result ( as bytes ).
        /// </summary>
        /// <param name="privateKey"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        //public static sbyte[] ApplyECDSASig(PrivateKey privateKey, string input)
        public static sbyte[] ApplyECDSASig(PrivateKey privateKey, byte[] input)
        {
            Signature dsa = new Signature();
            sbyte[] output = new sbyte[Secp256k1.SIGNATURE_LENGTH];
            try
            {
                using (var secp256k1 = new Secp256k1())
                {
                    /*
                    sbyte[] sbytes = Array.ConvertAll(input.ToCharArray(), q => Convert.ToSByte(q));
                    Span<byte> msgHash = new byte[Secp256k1.HASH_LENGTH];
                    for(int i=0; i < Secp256k1.HASH_LENGTH; i++)
                        msgHash[i] = (byte) sbytes[i];
                    */

                    Span<byte> msgHash = input;
                    dsa.signature = new byte[Secp256k1.SIGNATURE_LENGTH];
                    secp256k1.Sign(dsa.signature, msgHash, privateKey.privateKey);

                    for (int i = 0; i < Secp256k1.SIGNATURE_LENGTH; i++)
                        output[i] = (sbyte)dsa.signature[i];
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.ToString());
            }
            return output;
        }


        /// <summary>
        /// Verifies a String signature 
        /// </summary>
        /// <param name="publicKey"></param>
        /// <param name="data"></param>
        /// <param name="signature"></param>
        /// <returns></returns>
        //public static bool VerifyECDSASig(PublicKey key, string data, sbyte[] signature)
        public static bool VerifyECDSASig(PublicKey key, byte[] data, sbyte[] signature)
        {
            try
            {
                using (var secp256k1 = new Secp256k1())
                {
                    /*
                    sbyte[] sbytes = Array.ConvertAll(data.ToCharArray(), q => Convert.ToSByte(q));
                    Span<byte> msg = new byte[Secp256k1.HASH_LENGTH];

                    for (int i = 0; i < Secp256k1.HASH_LENGTH; i++)
                        msg[i] = (byte)sbytes[i];
                    */

                    Span<byte> signatureOutput = new byte[Secp256k1.SIGNATURE_LENGTH];

                    for (int i = 0; i < Secp256k1.SIGNATURE_LENGTH; i++)
                        signatureOutput[i] = (byte)signature[i];

                    //return secp256k1.Verify(signatureOutput, msg, publicKey.publicKey)
                    return secp256k1.Verify(signatureOutput, data, key.publicKey);
                }

            }
            catch (Exception e)
            {
                throw new Exception(e.ToString());
            }
        }


        /// <summary>
        /// Get public key as Base64 string
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string GetStringFromKey(PublicKey key)
        {
            return Convert.ToBase64String(key.publicKey);
        }


        /// <summary>
        /// Get MerkleRoot
        /// </summary>
        /// <param name="transactions"></param>
        /// <returns></returns>
        public static string GetMerkleRoot(List<Transaction> transactions)
        {
            int count = transactions.Count;

            IList<string> previousTreeLayer = new List<string>();
            foreach (Transaction transaction in transactions)
            {
                previousTreeLayer.Add(transaction.transactionId);
            }
            IList<string> treeLayer = previousTreeLayer;

            while (count > 1)
            {
                treeLayer = new List<string>();
                for (int i = 1; i < previousTreeLayer.Count; i += 2)
                {
                    treeLayer.Add(ApplySha256(previousTreeLayer[i - 1] + previousTreeLayer[i]));
                }
                count = treeLayer.Count;
                previousTreeLayer = treeLayer;
            }

            string merkleRoot = (treeLayer.Count == 1) ? treeLayer[0] : "";
            return merkleRoot;
        }
    }
}