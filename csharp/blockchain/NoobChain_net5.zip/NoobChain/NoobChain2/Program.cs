﻿using System;


namespace NoobChain
{
    class Program
    {
        static void Main(string[] args)
        {

            new NoobChain(4);

            Console.WriteLine(Environment.NewLine + "Press a key to exit");
            Console.ReadKey();
        }
    }
}
