﻿using Secp256k1Net;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;


namespace NoobChain
{
    public class PrivateKey
    {
        public byte[] privateKey { get; set; }
    }

    public class PublicKey
    {
        public byte[] publicKey { get; set; }
    }


    public class Wallet
	{
        /// <summary>
        /// Span: https://docs.microsoft.com/en-us/dotnet/api/system.span-1
        /// </summary>
        private ref struct KeyPair
        {
            public Span<byte> PrivateKey;
            public Span<byte> PublicKey;
        }

        public PrivateKey privateKey;
		public PublicKey publicKey;

        public Dictionary<string, TransactionOutput> UTXOs = new Dictionary<string, TransactionOutput>();

        /// <summary>
        /// Constructor, create keys at once
        /// </summary>
		public Wallet()
		{
            privateKey = new PrivateKey();
            publicKey = new PublicKey();

            GenerateKeyPair();
        }

        /// <summary>
        /// 
        /// </summary>
        public virtual void GenerateKeyPair()
        {
            try
            {
                using (var secp256k1 = new Secp256k1())
                {
                    var kp = GenerateKeyPair(secp256k1);

                    // https://msdn.microsoft.com/en-us/magazine/mt814808.aspx
                    privateKey.privateKey = kp.PrivateKey.ToArray();
                    publicKey.publicKey = kp.PublicKey.ToArray();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.ToString());
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="secp256k1"></param>
        /// <returns></returns>
        Span<byte> GeneratePrivateKey(Secp256k1 secp256k1)
        {
            var rnd = RandomNumberGenerator.Create();
            Span<byte> privateKey = new byte[Secp256k1.PRIVKEY_LENGTH];
            do
            {
                rnd.GetBytes(privateKey);
            }
            while (!secp256k1.SecretKeyVerify(privateKey));
            return privateKey;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="secp256k1"></param>
        /// <returns></returns>
        KeyPair GenerateKeyPair(Secp256k1 secp256k1)
        {
            var privateKey = GeneratePrivateKey(secp256k1);
            Span<byte> publicKey = new byte[Secp256k1.PUBKEY_LENGTH];

            if (!secp256k1.PublicKeyCreate(publicKey, privateKey))
            {
                throw new Exception("Public key creation failed");
            }
            return new KeyPair { PrivateKey = privateKey, PublicKey = publicKey };
        }


        /// <summary>
        /// 
        /// </summary>
        public virtual float Balance
		{
			get
			{
				float total = 0;
				foreach (KeyValuePair<string, TransactionOutput> item in NoobChain.UTXOs.SetOfKeyValuePairs())
				{
					TransactionOutput UTXO = item.Value;
					if (UTXO.IsMine(publicKey))
					{ //if output belongs to me ( if coins belong to me )
						UTXOs[UTXO.id] = UTXO; //add it to our list of unspent transactions.
						total += UTXO.value;
					}
				}
				return total;
			}
		}


        /// <summary>
        /// 
        /// </summary>
        /// <param name="recipient"></param>
        /// <param name="value"></param>
        /// <returns></returns>
		public virtual Transaction SendFunds(PublicKey recipient, float value)
		{
			if (Balance < value)
			{
				Console.WriteLine("#Not Enough funds to send transaction. Transaction Discarded.");
				return null;
			}
			List<TransactionInput> inputs = new List<TransactionInput>();

			float total = 0;
			foreach (KeyValuePair<string, TransactionOutput> item in UTXOs.SetOfKeyValuePairs())
			{
				TransactionOutput UTXO = item.Value;
				total += UTXO.value;
				inputs.Add(new TransactionInput(UTXO.id));
				if (total > value)
				{
					break;
				}
			}

			Transaction newTransaction = new Transaction(publicKey, recipient, value, inputs);
			newTransaction.GenerateSignature(privateKey);

			foreach (TransactionInput input in inputs)
			{
				UTXOs.Remove(input.transactionOutputId);
			}

			return newTransaction;
		}
	}
}