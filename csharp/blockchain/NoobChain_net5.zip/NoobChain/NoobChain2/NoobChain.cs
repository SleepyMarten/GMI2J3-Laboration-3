﻿using System;
using System.Collections.Generic;

namespace NoobChain
{
	public class NoobChain
	{
        public static List<Block> blockchain;
        public static int difficulty;

        // https://stackoverflow.com/questions/1273139/c-sharp-java-hashmap-equivalent
        public static Dictionary<string, TransactionOutput> UTXOs = new Dictionary<string, TransactionOutput>();
        public static float minimumTransaction = 0.1f;
        public static Wallet walletA;
        public static Wallet walletB;
        public static Transaction genesisTransaction;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="difficulty"></param>
        public NoobChain(int difficulty = 5)
		{
            NoobChain.difficulty = difficulty;
            blockchain = new List<Block>();

            //add our blocks to the blockchain ArrayList:

            //Create wallets:
            walletA = new Wallet();
            walletB = new Wallet();
            Wallet coinbase = new Wallet();

            //create genesis transaction, which sends 100 NoobCoin to walletA: 
            genesisTransaction = new Transaction(coinbase.publicKey, walletA.publicKey, 100f, null);
            genesisTransaction.GenerateSignature(coinbase.privateKey); //manually sign the genesis transaction
            genesisTransaction.transactionId = "0"; //manually set the transaction id
            genesisTransaction.outputs.Add(new TransactionOutput(genesisTransaction.reciepient, genesisTransaction.value, genesisTransaction.transactionId)); //manually add the Transactions Output
            UTXOs[genesisTransaction.outputs[0].id] = genesisTransaction.outputs[0]; //its important to store our first transaction in the UTXOs list.


            Console.WriteLine("Creating and Mining Genesis block... ");
            Block genesis = new Block("0");
            genesis.AddTransaction(genesisTransaction);
            AddBlock(genesis);


            // testing
            Block block1 = new Block(genesis.Hash);
            Console.WriteLine("\nWalletA's balance is: " + walletA.Balance);
            Console.WriteLine("\nWalletA is Attempting to send funds (40) to WalletB...");
            block1.AddTransaction(walletA.SendFunds(walletB.publicKey, 40f));
            AddBlock(block1);
            Console.WriteLine("\nWalletA's balance is: " + walletA.Balance);
            Console.WriteLine("WalletB's balance is: " + walletB.Balance);

            Block block2 = new Block(block1.Hash);
            Console.WriteLine("\nWalletA Attempting to send more funds (1000) than it has...");
            block2.AddTransaction(walletA.SendFunds(walletB.publicKey, 1000f));
            AddBlock(block2);
            Console.WriteLine("\nWalletA's balance is: " + walletA.Balance);
            Console.WriteLine("WalletB's balance is: " + walletB.Balance);

            Block block3 = new Block(block2.Hash);
            Console.WriteLine("\nWalletB is Attempting to send funds (20) to WalletA...");
            block3.AddTransaction(walletB.SendFunds(walletA.publicKey, 20));
            Console.WriteLine("\nWalletA's balance is: " + walletA.Balance);
            Console.WriteLine("WalletB's balance is: " + walletB.Balance);

            Block block4 = new Block(block3.Hash);
            Console.WriteLine("\nWalletB is Attempting to send funds (20) to WalletA...");
            block4.AddTransaction(walletB.SendFunds(walletA.publicKey, 20));
            Console.WriteLine("\nWalletA's balance is: " + walletA.Balance);
            Console.WriteLine("WalletB's balance is: " + walletB.Balance);


            Console.WriteLine("Blockchain is Valid: " + ChainValid);

            string blockchainJson = StringUtil.GetJson(blockchain);

            Console.WriteLine(Environment.NewLine + "The block chain: ");
            Console.WriteLine(blockchainJson);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="newBlock"></param>
        public static void AddBlock(Block newBlock)
        {
            newBlock.MineBlock(difficulty);
            blockchain.Add(newBlock);
        }


        /// <summary>
        /// 
        /// </summary>
        public static bool? ChainValid
        {
            get
            {
                Block currentBlock = blockchain[0];
                Block previousBlock;
                string hashTarget = (new string(new char[difficulty])).Replace('\0', '0');

                Dictionary<string, TransactionOutput> tempUTXOs = new Dictionary<string, TransactionOutput>
                {
                    // a temporary working list of unspent transactions at a given block state.
                    [genesisTransaction.outputs[0].id] = genesisTransaction.outputs[0]
                };

                Console.WriteLine(Environment.NewLine);

                // compare registered hash and calculated hash for first block
                string firstBlockHash = currentBlock.Hash;
                if (!firstBlockHash.Equals(currentBlock.CalculateHash()))
                {
                    Console.WriteLine("First Block Hashes not equal");
                    return false;
                }

                // loop through blockchain to check hashes:
                for (int i = 1; i < blockchain.Count; i++)
                {
                    currentBlock = blockchain[i];
                    previousBlock = blockchain[i - 1];
                    // compare registered hash and calculated hash
                    if (!currentBlock.Hash.Equals(currentBlock.CalculateHash()))
                    {
                        Console.WriteLine("Current Block Hashes not equal");
                        return false;
                    }
                    // compare previous hash and registered previous hash
                    if (!previousBlock.Hash.Equals(currentBlock.PreviousHash))
                    {
                        Console.WriteLine("Previous Block and Current Block Hashes not equal");
                        return false;
                    }
                    // check if hash is solved
                    if (!currentBlock.Hash.Substring(0, difficulty).Equals(hashTarget))
                    {
                        Console.WriteLine("This block hasn't been mined");
                        return false;
                    }

                    // loop thru blockchains transactions:
                    TransactionOutput tempOutput;
                    for (int t = 0; t < currentBlock.transactions.Count; t++)
                    {
                        Transaction currentTransaction = currentBlock.transactions[t];

                        if (!currentTransaction.VerifySignature())
                        {
                            Console.WriteLine("#Signature on Transaction(" + t + ") is Invalid");
                            return false;
                        }
                        if (currentTransaction.InputsValue != currentTransaction.OutputsValue)
                        {
                            Console.WriteLine("#Inputs are note equal to outputs on Transaction(" + t + ")");
                            return false;
                        }

                        foreach (TransactionInput input in currentTransaction.inputs)
                        {
                            tempOutput = tempUTXOs[input.transactionOutputId];

                            if (tempOutput == null)
                            {
                                Console.WriteLine("#Referenced input on Transaction(" + t + ") is Missing");
                                return false;
                            }

                            if (input.UTXO.value != tempOutput.value)
                            {
                                Console.WriteLine("#Referenced input Transaction(" + t + ") value is Invalid");
                                return false;
                            }

                            tempUTXOs.Remove(input.transactionOutputId);
                        }

                        foreach (TransactionOutput output in currentTransaction.outputs)
                        {
                            tempUTXOs[output.id] = output;
                        }

                        if (currentTransaction.outputs[0].reciepient != currentTransaction.reciepient)
                        {
                            Console.WriteLine("#Transaction(" + t + ") output reciepient is not who it should be");
                            return false;
                        }
                        if (currentTransaction.outputs[1].reciepient != currentTransaction.sender)
                        {
                            Console.WriteLine("#Transaction(" + t + ") output 'change' is not sender.");
                            return false;
                        }
                    }
                }
                return true;
            }
        }
    }
}