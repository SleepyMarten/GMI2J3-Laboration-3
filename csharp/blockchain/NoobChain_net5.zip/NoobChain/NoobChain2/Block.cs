﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NoobChain
{
	public class Block
	{
        public string Hash { get; set; }
        public string PreviousHash { get; set; }
        public string merkleRoot;
        public List<Transaction> transactions = new List<Transaction>(); //our data will be a simple message.
        public long TimeStamp;  // as number of milliseconds since 1/1/1970. MS: https://docs.microsoft.com/en-us/dotnet/api/system.datetime.ticks
        public int Nonce;       // In cryptography, a nonce is an arbitrary number that can be used just once in a cryptographic communication

        //private Object _lock = new Object();


        /// <summary>
        /// Block Constructor
        /// </summary>
        /// <param name="data"></param>
        /// <param name="previousHash"></param>
        public Block(string previousHash)
		{
			this.PreviousHash = previousHash;
			this.TimeStamp = (DateTime.Now).Ticks;
            //this.TimeStamp = 636891031919822359;    // for predictability in test, this.TimeStamp = 636891031919822359
            this.Hash = CalculateHash();            // Making sure we do this after we set the other values.
		}


        /// <summary>
        /// Calculate new hash based on blocks contents
        /// </summary>
        /// <returns></returns>
        public virtual string CalculateHash()
		{
			string calculatedhash = StringUtil.ApplySha256(PreviousHash + Convert.ToString(TimeStamp) + Convert.ToString(Nonce) + merkleRoot);
			return calculatedhash;
		}


        /// <summary>
        /// Increases nonce value until hash target is reached
        /// </summary>
        /// <param name="difficulty"></param>
        public virtual void MineBlock(int difficulty)
		{
            merkleRoot = StringUtil.GetMerkleRoot(transactions);
            string target = StringUtil.GetDifficultyString(difficulty); //Create a string with difficulty * "0"

			while (!Hash.Substring(0, difficulty).Equals(target))
			{
				Nonce++;
				Hash = CalculateHash();
                if (Nonce % 100000 == 0)
                    Console.Write(".");
            }

        /*          
            string localHash="";
            int localNonce = 0;
            // Parallel equivalent of for
            Parallel.For(0, int.MaxValue, (i, loopState) => {

                if (!hash.Substring(0, difficulty).Equals(target))
                {
                    lock (_lock)
                    {
                        nonce = i;
                        hash = CalculateHash();
                        if (nonce % 100000 == 0)
                            Console.Write(".");
                    }
                }
                else
                {
                    localNonce = nonce;
                    localHash = hash;
                    loopState.Stop();
                }
            });
            hash = localHash;
            nonce = localNonce;
*/
        Console.WriteLine(Environment.NewLine + "Block Mined! : " + Hash);
		}



        /// <summary>
        /// 
        /// </summary>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public virtual bool AddTransaction(Transaction transaction)
        {
            //process transaction and check if valid, unless block is genesis block then ignore.
            if (transaction == null)
            {
                return false;
            }
            if ((!"0".Equals(PreviousHash)))
            {
                if ((transaction.ProcessTransaction() != true))
                {
                    Console.WriteLine("Transaction failed to process. Discarded.");
                    return false;
                }
            }

            transactions.Add(transaction);
            Console.WriteLine("Transaction Successfully added to Block");
            return true;
        }
    }
}