﻿using NoobChain;
using System;

namespace NoobChain
{
	public class TransactionOutput
	{
		public string id;
		public PublicKey reciepient; //also known as the new owner of these coins.
		public float value; //the amount of coins they own
		public string parentTransactionId; //the id of the transaction this output was created in

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="reciepient"></param>
        /// <param name="value"></param>
        /// <param name="parentTransactionId"></param>
		public TransactionOutput(PublicKey reciepient, float value, string parentTransactionId)
		{
			this.reciepient = reciepient;
			this.value = value;
			this.parentTransactionId = parentTransactionId;
			this.id = StringUtil.ApplySha256(StringUtil.GetStringFromKey(reciepient) + Convert.ToString(value) + parentTransactionId);
		}


        /// <summary>
        /// Check if coin belongs to you
        /// </summary>
        /// <param name="publicKey"></param>
        /// <returns></returns>
        public virtual bool IsMine(PublicKey publicKey)
		{
			return (publicKey == reciepient);
		}
	}
}