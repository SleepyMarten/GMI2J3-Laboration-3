﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace NoobChain
{
	public class Transaction
	{
		public string transactionId; //Contains a hash of transaction*
		public PublicKey sender; //Senders address/public key.
		public PublicKey reciepient; //Recipients address/public key.
		public float value; //Contains the amount we wish to send to the recipient.
		public sbyte[] signature; //This is to prevent anybody else from spending funds in our wallet.

		public List<TransactionInput> inputs = new List<TransactionInput>();
		public List<TransactionOutput> outputs = new List<TransactionOutput>();

		private static int sequence = 0; //A rough count of how many transactions have been generated


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="value"></param>
        /// <param name="inputs"></param>
		public Transaction(PublicKey from, PublicKey to, float value, List<TransactionInput> inputs)
		{
			this.sender = from;
			this.reciepient = to;
			this.value = value;
			this.inputs = inputs;
		}


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
		public virtual bool ProcessTransaction()
		{

			if (VerifySignature() == false)
			{
				Console.WriteLine("#Transaction Signature failed to verify");
				return false;
			}

			//Gathers transaction inputs (Making sure they are unspent):
			foreach (TransactionInput i in inputs)
			{
				i.UTXO = NoobChain.UTXOs[i.transactionOutputId];
			}

			//Checks if transaction is valid:
			if (InputsValue < NoobChain.minimumTransaction)
			{
				Console.WriteLine("Transaction Inputs too small: " + InputsValue);
				Console.WriteLine("Please enter the amount greater than " + NoobChain.minimumTransaction);
				return false;
			}

			//Generate transaction outputs:
			float leftOver = InputsValue - value; //get value of inputs then the left over change:
			transactionId = CalulateHash();
			outputs.Add(new TransactionOutput(this.reciepient, value,transactionId)); //send value to recipient
			outputs.Add(new TransactionOutput(this.sender, leftOver,transactionId)); //send the left over 'change' back to sender

			//Add outputs to Unspent list
			foreach (TransactionOutput o in outputs)
			{
				NoobChain.UTXOs[o.id] = o;
			}

			//Remove transaction inputs from UTXO lists as spent:
			foreach (TransactionInput i in inputs)
			{
				if (i.UTXO == null)
				{
					continue; //if Transaction can't be found skip it
				}
				NoobChain.UTXOs.Remove(i.UTXO.id);
			}

			return true;
		}


        /// <summary>
        /// 
        /// </summary>
		public virtual float InputsValue
		{
			get
			{
				float total = 0;
                if (inputs != null)
                {
                    foreach (TransactionInput inp in inputs)
                    {
                        if (inp.UTXO == null)
                        {
                            continue; //if Transaction can't be found skip it, This behavior may not be optimal.
                        }
                        total += inp.UTXO.value;
                    }
                }
				return total;
			}
		}


        /// <summary>
        /// 
        /// </summary>
        /// <param name="privateKey"></param>
		public virtual void GenerateSignature(PrivateKey privateKey)
		{
			string data = StringUtil.GetStringFromKey(sender) + StringUtil.GetStringFromKey(reciepient) + Convert.ToString(value);

            byte[] messageHash = SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(data));

            //signature = StringUtil.applyECDSASig(privateKey, data);
            signature = StringUtil.ApplyECDSASig(privateKey, messageHash);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
		public virtual bool VerifySignature()
		{
			string data = StringUtil.GetStringFromKey(sender) + StringUtil.GetStringFromKey(reciepient) + Convert.ToString(value);

            byte[] messageHash = SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(data));

            //return StringUtil.verifyECDSASig(sender, data, signature);
            return StringUtil.VerifyECDSASig(sender, messageHash, signature);
        }


        /// <summary>
        /// 
        /// </summary>
		public virtual float OutputsValue
		{
			get
			{
				float total = 0;
				foreach (TransactionOutput o in outputs)
				{
					total += o.value;
				}
				return total;
			}
		}


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
		private string CalulateHash()
		{
			sequence++; //increase the sequence to avoid 2 identical transactions having the same hash
			return StringUtil.ApplySha256(StringUtil.GetStringFromKey(sender) + StringUtil.GetStringFromKey(reciepient) + Convert.ToString(value) + sequence);
		}
	}

}