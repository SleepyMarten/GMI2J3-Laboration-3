﻿using Newtonsoft.Json;
using NLog;
using System;
using System.Security.Cryptography;
using System.Text;

namespace NoobChain
{
	public class StringUtil
	{
        private static Logger logger = LogManager.GetCurrentClassLogger();
        /// <summary>
        /// Applies Sha256 to a string and returns the result
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string ApplySha256(string input)
		{
            StringBuilder hexString = new StringBuilder();
            using (var hash = SHA256.Create())
            {
                try
                {
                    byte[] hashBytes = hash.ComputeHash(Encoding.UTF8.GetBytes(input));
                    foreach (byte b in hashBytes)
                        hexString.Append(b.ToString("x2"));
                }
                catch (Exception ex) {
                    logger.Info(Environment.NewLine + "SHA exception: " + ex.ToString());
                }
            }
            return hexString.ToString();
        }


        /// <summary>
        /// Short hand helper to turn Object into a JSON string
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string GetJson(object obj)
		{
            return JsonConvert.SerializeObject(obj, Formatting.Indented);
        }


        /// <summary>
        /// Returns difficulty string target, to compare to hash. eg difficulty of 5 will return "00000" 
        /// </summary>
        /// <param name="difficulty"></param>
        /// <returns></returns>
        public static string GetDifficultyString(int difficulty)
		{
			return (new string(new char[difficulty])).Replace('\0', '0');
		}
	}
}
