﻿using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace NoobChain
{
    class NoobChain
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public static List<Block> blockchain;
        public static int difficulty;

        /// <summary>
        /// Constructor, use default difficulty of 2
        /// </summary>
        /// <param name="difficulty"></param>
        public NoobChain(int difficulty = 2)
        {
            NoobChain.difficulty = difficulty;

            logger.Info($"Mining with difficulty set to: {difficulty}");

            blockchain = new List<Block>();
            //add our blocks to the blockchain ArrayList:

            logger.Info("Trying to Mine block 1... ");
            AddBlock(new Block("Hi im the first block", "0"));

            logger.Info(Environment.NewLine + "Trying to Mine block 2... ");
            AddBlock(new Block("Yo im the second block", blockchain[blockchain.Count - 1].Hash));

            logger.Info(Environment.NewLine + "Trying to Mine block 3... ");
            AddBlock(new Block("Hey im the third block", blockchain[blockchain.Count - 1].Hash));

            logger.Info("\nBlockchain is Valid: " + ChainValid);

            string blockchainJson = StringUtil.GetJson(blockchain);
            logger.Info(Environment.NewLine + "The block chain: ");
            logger.Info(blockchainJson);
        }


        /// <summary>
        /// 
        /// </summary>
        public static bool? ChainValid
        {
            get
            {
                Block currentBlock = blockchain[0];
                Block previousBlock;
                string hashTarget = (new string(new char[difficulty])).Replace('\0', '0');

                Console.WriteLine(Environment.NewLine);

                //compare registered hash and calculated hash for first block
                string firstBlockHash = currentBlock.Hash;
                if (!firstBlockHash.Equals(currentBlock.CalculateHash()))
                {
                    logger.Info("First Block Hashes not equal");
                    return false;
                }

                //loop through blockchain to check hashes:
                for (int i = 1; i < blockchain.Count; i++)
                {
                    currentBlock = blockchain[i];
                    previousBlock = blockchain[i - 1];
                    //compare registered hash and calculated hash
                    if (!currentBlock.Hash.Equals(currentBlock.CalculateHash()))
                    {
                        logger.Info("Current Block Hashes not equal");
                        return false;
                    }
                    //compare previous hash and registered previous hash
                    if (!previousBlock.Hash.Equals(currentBlock.PreviousHash))
                    {
                        logger.Info("Previous Block and Current Block Hashes not equal");
                        return false;
                    }
                    //check if hash is solved
                    if (!currentBlock.Hash.Substring(0, difficulty).Equals(hashTarget))
                    {
                        logger.Info("This block hasn't been mined");
                        return false;
                    }
                }
                return true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="newBlock"></param>
        public static void AddBlock(Block newBlock)
        {
            newBlock.MineBlock(difficulty);
            blockchain.Add(newBlock);
        }
    }
}
