﻿using NLog;
using System;

namespace NoobChain
{
	public class Block
	{
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public string Hash { get; set; }
        public string PreviousHash { get; set; }
        public string Data { get; set; } // our data will be a simple message.
        public long TimeStamp;  // as number of milliseconds since 1/1/1970. MS: https://docs.microsoft.com/en-us/dotnet/api/system.datetime.ticks
        public int Nonce;       // In cryptography, a nonce is an arbitrary number that can be used just once in a cryptographic communication


        /// <summary>
        /// Block Constructor
        /// </summary>
        /// <param name="previousHash"></param>
        public Block(string data, string previousHash)
        {
            this.Data = data;
            this.PreviousHash = previousHash;
			this.TimeStamp = (DateTime.Now).Ticks;
            //this.TimeStamp = 636891031919822359;    // for predictability in test, this.TimeStamp = 636891031919822359
            this.Hash = CalculateHash();            // Making sure we do this after we set the other values.
		}


        /// <summary>
        /// Calculate new hash based on blocks contents
        /// </summary>
        /// <returns></returns>
        public virtual string CalculateHash()
		{
			string calculatedhash = StringUtil.ApplySha256(PreviousHash + Convert.ToString(TimeStamp) + Convert.ToString(Nonce) + Data);
			return calculatedhash;
		}


        /// <summary>
        /// Increases nonce value until hash target is reached
        /// </summary>
        /// <param name="difficulty"></param>
        public virtual void MineBlock(int difficulty)
		{
			string target = StringUtil.GetDifficultyString(difficulty); //Create a string with difficulty * "0"

			while (!Hash.Substring(0, difficulty).Equals(target))
			{
				Nonce++;
				Hash = CalculateHash();
                if (Nonce % 100000 == 0)
                    Console.Write(".");
            }

            logger.Info(Environment.NewLine + "Block Mined! : " + Hash);
		}
	}
}