﻿using NLog;
using System;
using System.Configuration;
using System.IO;

namespace NoobChain
{
    class Program
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public static int difficulty;

        static void Main(string[] args)
        {
            if (args.Length < 1 || string.IsNullOrEmpty(args[0]))
            {
                Console.WriteLine("You must specify the base directory for storing the logfile");
                Console.WriteLine("\nPress any key to exit.");
                Console.ReadKey();
                Environment.Exit(-1);
            }

            string targetDir = ConfigureNLog(args[0]);
            logger.Info($"This is how you use NLog to log to screen and a file: {targetDir}\n");

            TestAppsettings();

            difficulty = int.Parse(GetAppSettingValue("Difficulty"));

            new NoobChain(difficulty);

            Console.WriteLine(Environment.NewLine + "Press a key to exit");
            Console.ReadKey();
        }


        /// <summary>
        /// Init and configure NLog with a log file with appName.log in logFolderPath
        /// </summary>
        /// <param name="logFolderPath"></param>
        /// <returns>string</returns>
        public static string ConfigureNLog(string logFolderPath)
        {
            string targetDir = Path.Combine(logFolderPath, DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Directory.CreateDirectory(targetDir);
            // https://stackoverflow.com/questions/616584/how-do-i-get-the-name-of-the-current-executable-in-c
            string appName = AppDomain.CurrentDomain.FriendlyName;
            string nLogFile = Path.Combine(targetDir, appName /*.Substring(0, appName.IndexOf("."))*/ + ".log");
            NLogConfiguration.Configure(nLogFile);
            return nLogFile;
        }


        /// <summary>
        /// https://stackoverflow.com/questions/47591910/is-configurationmanager-appsettings-available-in-net-core-2-0
        /// </summary>
        public static void TestAppsettings()
        {
            string appSettingKey = "Var1";
            string value = GetAppSettingValue(appSettingKey);
            logger.Info($"GetAppSettingValue(): {value}");

            string connectionStringKey = "MSSQLConnectionString01";
            value = GetConnectionStringValue(connectionStringKey);
            logger.Info($"GetConnectionStringValue(): {value}" + Environment.NewLine);
        }


        /// <summary>
        /// Get AppSettingValue from App.config
        /// </summary>
        /// <param name="appSettingKey"></param>
        /// <returns></returns>
        public static string GetAppSettingValue(string appSettingKey)
        {
            string value = ConfigurationManager.AppSettings[appSettingKey];
            if (string.IsNullOrEmpty(value))
            {
                string message = $"Can not find value for appSetting key: '{appSettingKey}'.";
                throw new ConfigurationErrorsException(message);
            }
            return value;
        }


        /// <summary>
        /// Get ConnectionStringValue from App.config
        /// </summary>
        /// <param name="connectionStringKey"></param>
        /// <returns></returns>
        public static string GetConnectionStringValue(string connectionStringKey)
        {
            string value = ConfigurationManager.ConnectionStrings[connectionStringKey].ToString();
            if (string.IsNullOrEmpty(value))
            {
                string message = $"Can not find value for connectionString key: '{connectionStringKey}'.";
                throw new ConfigurationErrorsException(message);
            }
            return value;
        }
    }
}
