﻿using lab5cons.Models;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5cons
{
    class Controller
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private static RestSolcast restSolcast;
        private static DbLogger dbLogger;



        public Controller(string targetDir)
        {

            restSolcast = new RestSolcast();
            dbLogger = new DbLogger(targetDir);

            if (!dbLogger.ConnectionExists())
            {
                logger.Info("dbLogger got no connection!");
                Environment.Exit(1);
            }
        }


        /// <summary>
        /// Perform a SolcastRadiation and SolcastPV_power testing against hard coded data in RadiationForecast and PV_powerForecast
        /// </summary>
        public void TestSolcastExample()
        {

            // solcast object with PV_powerForecast List from Json
            SolcastPV_power solCastPV_power = SolcastPV_power.FromJson(PV_powerForecast.GetRawJsonExample());
            var pv_power = SerializePV_power.ToJson(solCastPV_power);   // back to Json
            logger.Info($"SolcastPV_power: {pv_power.ToString()}");


            var pv_powerForecasts = restSolcast.TestPV_powerJson(); // get List<PV_powerForecast>
            foreach (var pv_powerForecast in pv_powerForecasts) // PV_powerForecast object
            {
                logger.Info($"SolcastPV_powerForecast -> PvEstimate = {pv_powerForecast.PvEstimate}");
                logger.Info($"SolcastPV_powerForecast -> Period = {pv_powerForecast.Period}");
                logger.Info($"SolcastPV_powerForecast -> PeriodEnd = {pv_powerForecast.PeriodEnd}");
                dbLogger.AddPV_powerForecast(pv_powerForecast);
            }



            Console.WriteLine(Environment.NewLine);



            // solcast object with RadiationForecast List from Json
            SolcastRadiation solCastRadiation = SolcastRadiation.FromJson(RadiationForecast.GetRawJsonExample());
            var solcast = SerializeRadiation.ToJson(solCastRadiation);   // back to Json
            logger.Info($"SolcastRadiation: {solcast.ToString()}");


            var radiationForecasts = restSolcast.TestRadiationJson(); // get List<RadiationForecast>
            foreach (var radiationForecast in radiationForecasts) // RadiationForecast object
            {
                logger.Info($"SolcastRadiation -> AirTemp = {radiationForecast.AirTemp}");
                logger.Info($"SolcastRadiation -> Azimuth = {radiationForecast.Azimuth}");
                // ...
                // ...
                // ...
                dbLogger.AddRadiationForecast(radiationForecast);
            }
        }
    }
}
