﻿//#########################################################################################################
//# Get data from solcast api
/*
 * https://dzone.com/articles/web-api-with-httpclient-or-consume-web-api-from-co
 * https://stackoverflow.com/questions/26597665/how-to-get-content-body-from-a-httpclient-call
 * 
 */
//#########################################################################################################

namespace lab5cons.Models
{
    using NLog;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Threading.Tasks;


    public class RestSolcast
    {

        private static Logger logger = LogManager.GetCurrentClassLogger();

        private static String BaseAddress, RequestUri, Latitude, Longitude, ApiKey;
        private const String format = "json";   // we only support json
        private static int ConnectionTimeout = -1;
        private static int Capacity = 1000;
        private static HttpClient client;


        /// <summary>
        /// Create HTTP REST Solar client that consumes Solcast JSON files over HTTPS 
        /// </summary>
        public RestSolcast()
        {

            // examine if connectionString contains variables from from App.config
            if (true)
            {
                BaseAddress = @"https://api.solcast.com.au/"; 
                RequestUri = @"radiation/forecasts?"; // or pv_power/forecasts?
                Latitude = @"60.485";
                Longitude = @"15.416";
                ApiKey = @"EjU-LeKuqAM1csF1x5BXZs07ywETdOik";
                ConnectionTimeout = 5000;
                Capacity = 1000;

                client = new HttpClient
                {
                    BaseAddress = new Uri(@BaseAddress)
                };

                if (ConnectionTimeout > 0)
                {
                    client.Timeout = TimeSpan.FromMilliseconds(ConnectionTimeout);
                }

                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            }
        }


        ~RestSolcast()
        {
            if (client != null)
                client.Dispose();
        }


        /// <summary>
        /// Do we have a client?
        /// </summary>
        public bool ClientExists()
        {
            return client != null ? true : false;
        }



        /// <summary>
        /// TestJson
        /// https://www.codeproject.com/Articles/1201466/Working-with-JSON-in-Csharp-VB
        /// https://app.quicktype.io/#l=cs&r=json2csharp
        /// </summary>
        public List<RadiationForecast> TestRadiationJson()
        {
            var solcast = SolcastRadiation.FromJson(RadiationForecast.GetRawJsonExample());
            return solcast.RadiatonForecasts.ToList<RadiationForecast>();
        }

        /// <summary>
        /// TestJson
        /// https://www.codeproject.com/Articles/1201466/Working-with-JSON-in-Csharp-VB
        /// https://app.quicktype.io/#l=cs&r=json2csharp
        /// </summary>
        public List<PV_powerForecast> TestPV_powerJson()
        {
            var solcast = SolcastPV_power.FromJson(PV_powerForecast.GetRawJsonExample());
            return solcast.PV_powerForecasts.ToList<PV_powerForecast>();
        }



        /// <summary> 
        /// Get radiation forecast data from Solcast API https://solcast.com.au/api/radiation.html
        /// Example Radiation Forecast request:
        /// https://api.solcast.com.au/radiation/forecasts?longitude=15.485&latitude=60.416&api_key=EjU-LeKuqAM1csF1x5BXZs07ywETdOik&format=json 
        /// </summary>
        /// 
        public void GetRadiationForecast()
        {
        }

        /// <summary>
        /// Get PV power forecast data from Solcast API https://solcast.com.au/api/pv-power-requests.html
        /// Example PV Power Forecast request:
        /// https://api.solcast.com.au/pv_power/forecasts?longitude=15.485&latitude=60.416&capacity=1000&api_key=EjU-LeKuqAM1csF1x5BXZs07ywETdOik&format=json
        /// </summary>
        /// 
        public void GetPV_powerForecast()
        {
        }
    }
}


