﻿//#########################################################################################################
//# JSON for Solcast radiation, needs Newtonsoft.Json Nuget package 
// https://app.quicktype.io/#l=cs&r=json2csharp or http://json2csharp.com/
// To parse this JSON data, add NuGet 'Newtonsoft.Json' then do:
//    var solcast = SolcastRadiation.FromJson(jsonData);
// or var solcast = SerializeRadiation.ToJson(solCastRadiation);
//#########################################################################################################

namespace lab5cons.Models
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using System;
    using System.Collections.Generic;
    using System.Globalization;

    public partial class SolcastRadiation
    {
        [JsonProperty("forecasts")]
        public List<RadiationForecast> RadiatonForecasts { get; set; }
    }

    public partial class RadiationForecast
    {
        [JsonProperty("ghi")]
        public long Ghi { get; set; }

        [JsonProperty("ghi90")]
        public long Ghi90 { get; set; }

        [JsonProperty("ghi10")]
        public long Ghi10 { get; set; }

        [JsonProperty("ebh")]
        public long Ebh { get; set; }

        [JsonProperty("dni")]
        public long Dni { get; set; }

        [JsonProperty("dni10")]
        public long Dni10 { get; set; }

        [JsonProperty("dni90")]
        public long Dni90 { get; set; }

        [JsonProperty("dhi")]
        public long Dhi { get; set; }

        [JsonProperty("air_temp")]
        public long AirTemp { get; set; }

        [JsonProperty("zenith")]
        public long Zenith { get; set; }

        [JsonProperty("azimuth")]
        public long Azimuth { get; set; }

        [JsonProperty("cloud_opacity")]
        public long CloudOpacity { get; set; }

        [JsonProperty("period_end")]
        public DateTimeOffset PeriodEnd { get; set; }

        [JsonProperty("period")]
        public string Period { get; set; }


        /*
         * For testing the JSON without Web API
         */
        public static string GetRawJsonExample()
        {
            string rawJson = @"{'forecasts':[{'ghi':0,'ghi90':0,'ghi10':0,'ebh':0,'dni':0,'dni10':0,'dni90':0,'dhi':0,'air_temp':9,'zenith':139,'azimuth':178,'cloud_opacity':13,'period_end':'2018-10-08T14:00:00.0000000Z','period':'PT30M'},
                    {'ghi':0,'ghi90':0,'ghi10':0,'ebh':0,'dni':0,'dni10':0,'dni90':0,'dhi':0,'air_temp':12,'zenith':136,'azimuth':168,'cloud_opacity':30,'period_end':'2018-10-15T13:30:00.0000000Z','period':'PT30M'}]}";
            return rawJson;
        }
    }

    public partial class SolcastRadiation
    {
        public static SolcastRadiation FromJson(string json) => JsonConvert.DeserializeObject<SolcastRadiation>(json, ConverterRadiaton.Settings);
    }

    public static class SerializeRadiation
    {
        public static string ToJson(this SolcastRadiation self) => JsonConvert.SerializeObject(self, ConverterRadiaton.Settings);
    }

    internal static class ConverterRadiaton
    {
        public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            DateParseHandling = DateParseHandling.None,
            Converters = {
                    new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
                },
        };
    }
}



