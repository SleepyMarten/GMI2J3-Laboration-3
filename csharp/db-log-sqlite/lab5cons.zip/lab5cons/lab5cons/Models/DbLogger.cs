﻿//#########################################################################################################
//# Logs data to local DB, needs System.Data.SQLite Nuget package
//#########################################################################################################

namespace lab5cons.Models
{
    using NLog;
    using System;
    using System.Collections.Generic;
    using System.Data.SQLite;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;


/*
    DbConnection = new SQLiteConnection(@"Data Source=MyDb.db3;Version=3;");
    https://www.codeproject.com/Tips/1057992/Using-SQLite-An-Example-of-CRUD-Operations-in-Csha
 */
    public class DbLogger
    {

        private static Logger logger = LogManager.GetCurrentClassLogger();

        private static SQLiteConnection DbConnection;


        /// <summary>
        /// Create DB logger
        /// </summary>
        /// <param name="targetDir"></param>
        public DbLogger(string targetDir)
        {


            // examine if the config contains: connectionString="Data Source=ModbusDb.db3;Version=3;FailIfMissing=True;Foreign Keys=True"/>
            string curDbFile = @Path.Combine(targetDir, "Solcast.db3");
            string connectionString = @"Data Source=" + curDbFile + "; Version=3; FailIfMissing=True; Foreign Keys=True;";

            // examine if connectionString contains variables from from App.config
            if (true)
            {
                try
                {
                    using (DbConnection = new SQLiteConnection(connectionString))
                    {
                        // if db were not created (already existing) we need to create tables etc.
                        if (!File.Exists(curDbFile))
                        {
                            SQLiteConnection.CreateFile(curDbFile);
                            DbConnection = new SQLiteConnection(connectionString);
                            logger.Info(CreateTables() ? "DB tables created!" : "DB tables could not be created!");
                        }
                    }
                }
                catch (SQLiteException e)
                {
                    logger.Info("SQLiteException: {0}", e.ToString());
                }

            }
        }


        /// <summary>
        /// Do we have a connection?
        /// </summary>
        public bool ConnectionExists()
        {
            return DbConnection != null ? true : false;
        }


        /// <summary>
        /// Close DB
        /// </summary>
        public void CloseDb()
        {
            DbConnection.Dispose();
        }

        ~DbLogger()
        {
            DbConnection = null;
        }


        /// <summary>
        /// Create SQLite DB tables
        /// </summary>
        /// <returns>bool true/false</returns>
        private bool CreateTables()
        {
            try
            {
                DbConnection.Open();

                // {'forecasts':[{'period_end':'2018 - 10 - 09T10: 30:00.0000000Z','period':'PT30M','pv_estimate':0},
                string sql1 = @"CREATE TABLE IF NOT EXISTS PV_powerForecast (Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE,
                            pv_estimate TEXT,
                            period TEXT,
                            period_end TEXT
                        )";

                // {'forecasts':[{'ghi':0,'ghi90':0,'ghi10':0,'ebh':0,'dni':0,'dni10':0,'dni90':0,'dhi':0,'air_temp':9,'zenith':139,
                // 'azimuth':178,'cloud_opacity':13,'period_end':'2018-10-08T14:00:00.0000000Z','period':'PT30M'},
                string sql2 = @"CREATE TABLE IF NOT EXISTS RadiationForecast (Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE,
                            [ghi] TEXT,
                            [ghi90] TEXT,
                            [ghi10] TEXT,
                            [ebh] TEXT,
                            [dni] TEXT,
                            [dni10] TEXT,
                            [dni90] TEXT,
                            [dhi] TEXT,
                            [air_temp] TEXT,
                            [zenith] TEXT,
                            [azimuth] TEXT,
                            [cloud_opacity] TEXT,
                            [period_end] TEXT,
                            [period] TEXT
                        )";

                using (SQLiteCommand cmd = new SQLiteCommand(sql1, DbConnection))
                {
                    cmd.ExecuteNonQuery();
                }

                using (SQLiteCommand cmd = new SQLiteCommand(sql2, DbConnection))
                {
                    cmd.ExecuteNonQuery();
                }

                return true;
            }
            catch (SQLiteException e) {
                logger.Info("SQLiteException: {0}", e.ToString());
            }
            finally
            {
                DbConnection.Close();
            }

            return false;
        }


        /// <summary>
        /// Add data to Nibe DB
        /// </summary>
        /// <param name="radiationForecast"></param>
        /// <returns>int result</returns>
        public int AddRadiationForecast(RadiationForecast radiationForecast)
        {
            logger.Info("DbLogger.AddRadiationForecast()");

            int result = -1;

            DbConnection.Open();

            using (SQLiteCommand cmd = new SQLiteCommand(DbConnection))
            {
                cmd.CommandText = "INSERT INTO RadiationForecast (ghi, ghi90, ghi10, ebh, dni, dni10, dni90, dhi, air_temp, zenith, azimuth, cloud_opacity, period_end, period) " + 
                                "VALUES (@1, @2, @3, @4, @5, @6, @7, @8, @9, @10, @11, @12, @13, @14)";
                cmd.Prepare();
                cmd.Parameters.AddWithValue("@1", radiationForecast.Ghi);
                cmd.Parameters.AddWithValue("@2", radiationForecast.Ghi90);
                cmd.Parameters.AddWithValue("@3", radiationForecast.Ghi10);
                cmd.Parameters.AddWithValue("@4", radiationForecast.Ebh);
                cmd.Parameters.AddWithValue("@5", radiationForecast.Dni);
                cmd.Parameters.AddWithValue("@6", radiationForecast.Dni10);
                cmd.Parameters.AddWithValue("@7", radiationForecast.Dni90);
                cmd.Parameters.AddWithValue("@8", radiationForecast.Dhi);
                cmd.Parameters.AddWithValue("@9", radiationForecast.AirTemp);
                cmd.Parameters.AddWithValue("@10", radiationForecast.Zenith);
                cmd.Parameters.AddWithValue("@11", radiationForecast.Azimuth);
                cmd.Parameters.AddWithValue("@12", radiationForecast.CloudOpacity);
                cmd.Parameters.AddWithValue("@13", radiationForecast.PeriodEnd);
                cmd.Parameters.AddWithValue("@14", radiationForecast.Period);

                try
                {
                    result = cmd.ExecuteNonQuery();
                    return result;
                }
                catch (SQLiteException e)
                {
                    logger.Info("SQLiteException: {0}", e.ToString());
                }
                finally
                {
                    DbConnection.Close();
                }
            }

            return result;
        }


        /// <summary>
        /// Add data to PV_powerForecast SQLiteDB table
        /// </summary>
        /// <param name="PV_powerForecast"></param>
        /// <returns>int result</returns>
        public int AddPV_powerForecast(PV_powerForecast pV_PowerForecast)
        {
            logger.Info("DbLogger.AddPV_powerForecast()");

            int result = -1;

            DbConnection.Open();

            using (SQLiteCommand cmd = new SQLiteCommand(DbConnection))
            {
                cmd.CommandText = "INSERT INTO PV_powerForecast (pv_estimate, period, period_end) VALUES (@1, @2, @3)";
                cmd.Prepare();
                cmd.Parameters.AddWithValue("@1", pV_PowerForecast.PvEstimate);
                cmd.Parameters.AddWithValue("@2", pV_PowerForecast.Period);
                cmd.Parameters.AddWithValue("@3", pV_PowerForecast.PeriodEnd);
                try
                {
                    result = cmd.ExecuteNonQuery();
                    return result;
                }
                catch (SQLiteException e)
                {
                    logger.Info("SQLiteException: {0}", e.ToString());
                }
                finally
                {
                    DbConnection.Close();
                }
            }

            return result;
        }
    }
}
