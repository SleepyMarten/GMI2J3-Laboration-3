﻿//#########################################################################################################
//# JSON for Solcast pv_power, needs Newtonsoft.Json Nuget package 
// https://app.quicktype.io/#l=cs&r=json2csharp or http://json2csharp.com/
// To parse this JSON data, add NuGet 'Newtonsoft.Json' then do:
//    var solcastPV_power = SolcastPV_power.FromJson(jsonData);
// or var pv_power = SerializePV_power.ToJson(solCastPV_power);
//#########################################################################################################


namespace lab5cons.Models
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using System;
    using System.Collections.Generic;
    using System.Globalization;

    public partial class SolcastPV_power
    {
        [JsonProperty("forecasts")]
        public List<PV_powerForecast> PV_powerForecasts { get; set; }
    }

    public partial class PV_powerForecast
    {
   
        [JsonProperty("pv_estimate")]
        public long PvEstimate { get; set; }

        [JsonProperty("period_end")]
        public DateTimeOffset PeriodEnd { get; set; }

        [JsonProperty("period")]
        public string Period { get; set; }


        /*
         * For testing the JSON without Web API
         */
        public static string GetRawJsonExample()
        {
            string rawJson = @"{'forecasts':[{'period_end':'2018 - 10 - 09T10: 30:00.0000000Z','period':'PT30M','pv_estimate':0}, 
                {'period_end':'2018 - 10 - 16T10: 00:00.0000000Z','period':'PT30M','pv_estimate':0}]}";
            return rawJson;
        }
    }



    public partial class SolcastPV_power
    {
        public static SolcastPV_power FromJson(string json) => JsonConvert.DeserializeObject<SolcastPV_power>(json, ConverterPV_power.Settings);
    }

    public static class SerializePV_power
    {
        public static string ToJson(this SolcastPV_power self) => JsonConvert.SerializeObject(self, ConverterPV_power.Settings);
    }

    internal static class ConverterPV_power
    {
        public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            DateParseHandling = DateParseHandling.None,
            Converters = {
                    new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
                },
        };
    }
}



