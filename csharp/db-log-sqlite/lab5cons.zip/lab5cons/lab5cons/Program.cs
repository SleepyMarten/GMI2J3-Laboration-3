using NLog;
using System;
using System.IO;

namespace lab5cons
{
    class Program
    {
        // below is how to get the logger which can be done from any class after ConfigureNLog() is run once
        private static Logger logger = LogManager.GetCurrentClassLogger();

        private static Controller controller;

        static void Main(string[] args)
        {
            if (args.Length < 1 || string.IsNullOrEmpty(args[0]))
            {
                Console.WriteLine("You must specify the base directory for where to store the log and DB file!");
                Console.WriteLine("\nPress any key to exit.");
                Console.ReadKey();
                Environment.Exit(-1);
            }

            string targetDir = ConfigureNLog(args[0]);
            logger.Info($"This is how you use NLog to log to screen and a file: {targetDir}\n");

            // test JSON and DB       
            controller = new Controller(targetDir);
            controller.TestSolcastExample();


            Console.WriteLine("\nPress any key to exit.");
            Console.ReadKey();
        }

        // init and configure NLog with a log file with appName.log in logFolderPath
        public static string ConfigureNLog(string logFolderPath)
        {
            string targetDir = Path.Combine(logFolderPath, DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Directory.CreateDirectory(targetDir);
            // https://stackoverflow.com/questions/616584/how-do-i-get-the-name-of-the-current-executable-in-c
            string appName = System.AppDomain.CurrentDomain.FriendlyName;
            string nLogFile = Path.Combine(targetDir, appName /*.Substring(0, appName.IndexOf("."))*/ + ".log");
            NLogConfiguration.Configure(nLogFile);
            return targetDir;
        }
    }
}
